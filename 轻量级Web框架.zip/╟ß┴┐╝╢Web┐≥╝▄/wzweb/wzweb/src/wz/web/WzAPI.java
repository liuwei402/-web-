package wz.web;

import javax.servlet.http.HttpServletRequest;

public interface WzAPI
{
	public String exec(HttpServletRequest request);
}